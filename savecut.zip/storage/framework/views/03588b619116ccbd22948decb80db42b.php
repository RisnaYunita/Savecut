<!DOCTYPE html>
<html>
<head>
    <title>Account Verification</title>
</head>
<body>
    <p>Halloo <b><?php echo e($details['name']); ?></b>!!</p>
    <p>Berikut ini adalah Data Anda:</p>
    <table>
      <tr>
        <td>Name</td>
        <td>:</td>
        <td><?php echo e($details['name']); ?></td>
      </tr>
      <tr>
        <td>Website</td>
        <td>:</td>
        <td><?php echo e($details['website']); ?></td>
      </tr>
      <tr>
        <td>Register Date</td>
        <td>:</td>
        <td><?php echo e($details['datetime']); ?></td>
      </tr>
    </table>

    <center>
      <h3>Click this link to verify your account:</h3>
      <a href="<?php echo e($details['url']); ?>"><b style="color:blue">Verify</b></a>
      <h3>If you can't, Copy this link to your browser </h3>
      <p><?php echo e($details['url']); ?></p>
    </center>

  <p>Thank you for your registration! </p>
</body>
</html>
<?php /**PATH C:\laragon\www\savecut\resources\views/mail/mailTemplate.blade.php ENDPATH**/ ?>