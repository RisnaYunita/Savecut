<?php $__env->startSection('title', 'Customer Review List'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
  <div class="col-12 ms-3 mb-3">
    <div class="row">
      <h3 class="col-lg-10 col-md-9">Salon List</h3>
    </div>
    <?php if(session('deletereview')): ?>
      <div class="alert alert-success">
                <?php echo e(session('deletereview')); ?>

      </div>
    <?php endif; ?>
  </div>
  <div class="table-responsive text-nowrap py-3 px-4">
    <table id="datatable" class="table">
      <thead class="table-light">
        <tr>
          <th>User Name</th>
          <th>Rating</th>
          <th>Comment</th>
        </tr>
      </thead>
      <tbody class="table-border-bottom-0">
      <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($review->user->name); ?></td>
          <td>
            <?php for($i = 1; $i <= 5; $i++): ?>
              <?php if($i <= $review->rating): ?>
                <i class="mdi mdi-star active"></i> <!-- Filled star icon -->
              <?php else: ?>
                <i class="mdi mdi-star"></i> <!-- Empty star icon -->
              <?php endif; ?>
            <?php endfor; ?></td>
          <td><?php echo e($review->comment); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/ownercontentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\savecut\resources\views/content/owner/reviewlist-owner.blade.php ENDPATH**/ ?>