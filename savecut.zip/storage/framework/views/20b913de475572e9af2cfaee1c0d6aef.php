<?php $__env->startSection('title', 'Treatment'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-12">
  <div class="card">
    <h5 class="card-header">Treatment List</h5>
    <hr class="mt-0">
    <div class="card-body">
      <?php $__currentLoopData = $treatment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class = "row">
          <div class="col-lg-6" style="width: 800px; height: 600px; overflow: hidden;">
            <img src="<?php echo e(asset('storage/' . $treatment->treatment_image)); ?>" alt="error" class="w-100" />
          </div>
          <div class="col-lg-6">
            <h1 class="fw-bold mt-3">
              <?php echo e($treatment->treatment_name); ?>

            </h1>
            <hr>
            <h3>
              Price
            </h3>
            <h5 class="w-100 text-muted">
              <?php echo e($treatment->treatment_price); ?>

            </h5>
            <hr>
            <h3>
              Description
            </h3>
            <h5 class="w-100 text-muted">
              <?php echo e($treatment->treatment_description); ?>

            </h5>
          </div>
        </div>
        <div class="divider text-end">
          <div class="divider-text">
            <i class="mdi mdi-content-cut mdi-rotate-180"></i>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\savecut\resources\views/content/guest/treatment.blade.php ENDPATH**/ ?>