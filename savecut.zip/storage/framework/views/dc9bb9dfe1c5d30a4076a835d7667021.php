<!DOCTYPE html>
<html>
<head>
</head>
<body>

    <center>
      <h3>Copy this link to your browser to reset your password:</h3>
      <a href="<?php echo e(route('resetpassword', $token)); ?>">Reset Password</a>
    </center>

</body>
</html>
<?php /**PATH C:\laragon\www\savecut\resources\views/mail/forgetPasswordTemplate.blade.php ENDPATH**/ ?>