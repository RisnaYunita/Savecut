<?php $__env->startSection('title', 'Invoice'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-12">
    <div class="card">
      <h5 class="card-header">Invoice</h5>
      <div class="card-body">
        <h6>Booking Details</h6>
        <div class="row">
            <hr>
            <h6><strong>Name:</strong> <?php echo e($booking->fullname ?? 'N/A'); ?></h6>
            <h6><strong>Salon:</strong> <?php echo e($booking->salon->salon_name); ?></h6>
            <h6><strong>Treatment:</strong> <?php echo e($booking->treatment->treatment_name); ?></h6>
            <h6><strong>Date:</strong> <?php echo e($booking->booking_date->format('Y-m-d')); ?></h6>
            <h6><strong>Time:</strong> <?php echo e($booking->booking_time); ?></h6>
            <h6><strong>Price:</strong> <?php echo e($booking->booking_price); ?></h6>
            <h6><strong>Payment Status:</strong>
              <?php if($booking->payment_status == 'paid'): ?>
                  <span class="badge rounded-pill bg-label-success">Paid</span>
              <?php else: ?>
                  <span class="badge rounded-pill bg-label-danger">Unpaid</span>
              <?php endif; ?>
            </h6>
        </div>
      </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\savecut\resources\views/content/guest/invoice.blade.php ENDPATH**/ ?>