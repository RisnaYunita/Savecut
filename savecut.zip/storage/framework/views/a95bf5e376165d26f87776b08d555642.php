<?php $__env->startSection('title', 'Reset Password'); ?>

<?php $__env->startSection('page-style'); ?>
<!-- Page -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/pages/page-auth.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="position-relative">
  <div class="authentication-wrapper authentication-basic container-p-y">
    <div class="authentication-inner py-4">

      <div class="card p-2">
        <!-- Logo -->
        <div class="app-brand justify-content-center mt-5">
          <a href="<?php echo e(url('/')); ?>" class="app-brand-link gap-2">
            <?php echo $__env->make('_partials.macros',["height"=>30], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </a>
        </div>
        <!-- /Logo -->
        <!-- Reset Password -->
        <div class="card-body">
          <h4 class="mb-2">Reset Password 🔒</h4>
          <p class="mb-4">Your new password must be different from previously used passwords</p>
          <form id="formAuthentication" class="mb-3" action="<?php echo e(route('actionreset')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo e($token); ?>">
            <div class="form-floating form-floating-outline mb-3">
              <input type="text" class="form-control" id="email" name="email" placeholder="Enter your email" required autofocus>
              <label>Email</label>
              <?php if($errors->has('email')): ?>
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
              <?php endif; ?>
            </div>
            <div class="mb-3 form-password-toggle">
              <div class="input-group input-group-merge">
                <div class="form-floating form-floating-outline">
                  <input type="password" id="password" class="form-control" name="password" placeholder="············" required autofocus>
                  <label for="password">New Password</label>
                </div>
                <span class="input-group-text cursor-pointer"><i class="mdi mdi-eye-off-outline"></i></span>
                <?php if($errors->has('password')): ?>
                  <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
              </div>
            </div>
            <div class="mb-3 form-password-toggle">
              <div class="input-group input-group-merge">
                <div class="form-floating form-floating-outline">
                  <input type="password" id="confirm-password" class="form-control" name="password_confirmation" placeholder="············" required autofocus>
                  <label for="confirm-password">Confirm Password</label>
                </div>
                <span class="input-group-text cursor-pointer"><i class="mdi mdi-eye-off-outline"></i></span>
                <?php if($errors->has('password_confirmation')): ?>
                    <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                <?php endif; ?>
              </div>
            </div>
            <button class="btn btn-primary d-grid w-100 mb-3 waves-effect waves-light">
              Reset Password
            </button>
            <div class="text-center">
              <a href="<?php echo e(url('auth/login')); ?>" class="d-flex align-items-center justify-content-center">
                <i class="mdi mdi-chevron-left scaleX-n1-rtl mdi-24px"></i>
                Back to login
              </a>
            </div>
          <input type="hidden"></form>
        </div>
      </div>
      <!-- /Reset Password -->
      <img src="<?php echo e(asset('assets/img/illustrations/scissor.png')); ?>" alt="auth-tree" class="authentication-image-object-left d-none d-lg-block">
      <img src="<?php echo e(asset('assets/img/illustrations/auth-basic-mask-light.png')); ?>" class="authentication-image d-none d-lg-block" alt="triangle-bg">
      <img src="<?php echo e(asset('assets/img/illustrations/straightener.png')); ?>" alt="auth-tree" class="authentication-image-object-right d-none d-lg-block">
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/blankLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\savecut\resources\views/content/authentications/resetpassword.blade.php ENDPATH**/ ?>