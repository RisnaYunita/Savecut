<?php $__env->startSection('title', 'Booking List'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
  <div class="col-12 ms-3 mb-3">
    <div class="row">
      <h3 class="col-lg-10 col-md-9">Booking List</h3>
    </div>
    <?php if(session('success')): ?>
    <div class="alert alert-success">
    <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
    <div class="alert alert-danger">
    <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>
  </div>
  <div class="table-responsive text-nowrap py-3 px-4">
    <table id="datatable"class="table table-hover">
      <thead class="table-light">
        <tr>
          <th>Name</th>
          <th>Treatment</th>
          <th>Date</th>
          <th>Time</th>
          <th>Price</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($booking->payment_status == 'paid'): ?>
        <tr>
          <td><?php echo e($booking->fullname); ?></td>
          <td><?php echo e($booking->treatment->treatment_name); ?></td>
          <td><?php echo e($booking->booking_date->format('Y-m-d')); ?></td>
          <td><?php echo e($booking->booking_time); ?></td>
          <td><?php echo e($booking->treatment->treatment_price); ?></td>
          <td>
            <?php if($booking->status == 'done'): ?>
              <span class="badge rounded-pill bg-label-success me-1">Done</span>
            <?php elseif($booking->status == 'pending'): ?>
              <span class="badge rounded-pill bg-label-warning me-1">Pending</span>
            <?php elseif($booking->status == 'expired'): ?>
              <span class="badge rounded-pill bg-label-danger me-1">Expired</span>
            <?php endif; ?>
          </td>
          <td>
            <div class="dropdown">
              <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="mdi mdi-dots-vertical"></i></button>
              <div class="dropdown-menu">
                <?php if($booking->status == 'pending'): ?>
                  <form  class="dropdown_item" action="<?php echo e(route('mark.as.done', $booking->booking_id)); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('PATCH'); ?>
                      <div class="form-check ms-3">
                        <input class="form-check-input" type="checkbox" id="markAsDone<?php echo e($booking->booking_id); ?>" name="status" value="done" onchange="this.form.submit()" />
                        <label class="form-check-label"for="markAsDone<?php echo e($booking->booking_id); ?>">Mark as Done</label>
                      </div>
                  </form>
                <?php endif; ?>
                <form action="<?php echo e(route('deleteBooking', ['booking_id' => $booking->booking_id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="dropdown-item" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')"><i class="mdi mdi-trash-can-outline me-1" ></i> Delete</button>
                </form>
              </div>
            </div>
          </td>
        </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/ownercontentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\savecut\resources\views/content/owner/bookinglist-owner.blade.php ENDPATH**/ ?>