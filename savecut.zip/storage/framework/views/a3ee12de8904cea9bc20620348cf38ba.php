<?php
$color = $color ?? '#9055FD';
?>
<span style="color:<?php echo e($color); ?>;">
  <svg height="90" viewBox="0 0 160 90" width="160" fill="none">
    <image xlink:href="<?php echo e(asset('assets/img/icons/brands/logop2.png')); ?>" width="100%" height="100%" />
  </svg>
</span>
<?php /**PATH C:\laragon\www\savecut\resources\views/_partials/macros.blade.php ENDPATH**/ ?>