<?php

namespace App\Http\Controllers\landing;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LandingPage extends Controller
{
  public function index()
  {
    return view('content.landing-page.landing');
  }
}
