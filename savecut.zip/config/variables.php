<?php
// Variables
return [
  'creatorName' => 'SaveCut',
  'creatorUrl' => 'https://savecut.test',
  'templateName' => 'SaveCut',
];
